import numpy as np
import pandas as pd

df = pd.DataFrame({
    'X': np.random.uniform(0, 1, 10),
    'Y': np.random.uniform(0, 1, 10),
})

print(df)
print()
print('\t\t\t\tThis is New Release')
print()

print('Program Ended')
